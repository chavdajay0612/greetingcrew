package com.example.greetingcrew

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
