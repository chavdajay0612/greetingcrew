// // import 'package:flutter/material.dart';
// //
// // void main() {
// //   runApp(template());
// // }
// //
// // class Template {
// //   final String name;
// //   final String content;
// //
// //   Template({required this.name, required this.content});
// // }
// //
// // class Template1 {
// //   final String name;
// //   final String content;
// //
// //   Template1({required this.name, required this.content});
// // }
// // class template extends StatelessWidget {
// //   @override
// //   Widget build(BuildContext context) {
// //     return MaterialApp(
// //       title: 'Greeting App',
// //       theme: ThemeData(
// //         primarySwatch: Colors.blue,
// //       ),
// //       home: GreetingPage(),
// //     );
// //   }
// // }
// //
// // class GreetingPage extends StatefulWidget {
// //   @override
// //   _GreetingPageState createState() => _GreetingPageState();
// // }
// //
// // class _GreetingPageState extends State<GreetingPage> {
// //   bool isAnniversarySelected = false;
// //   bool isBirthdaySelected = false;
// //   List<Template> templates = [
// //     Template(name: 'Template 1', content: 'Happy occasion!'),
// //     Template(name: 'Template 2', content: 'Wishing you a wonderful day!'),
// //     // Add more templates as needed
// //   ];
// //   Template? selectedTemplate;
// //
// //   List<Template1> templates1 = [
// //     Template1(name: 'Template 1', content: 'Happy occasion!'),
// //     Template1(name: 'Template 2', content: 'Wishing you a wonderful day!'),
// //     // Add more templates as needed
// //   ];
// //   Template1? selectedTemplate1;
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: Text('Greeting App'),
// //       ),
// //       body: Center(
// //         child: Column(
// //           mainAxisAlignment: MainAxisAlignment.center,
// //           crossAxisAlignment: CrossAxisAlignment.center,
// //           children: [
// //             CheckboxListTile(
// //               title: Text('Anniversary'),
// //               value: isAnniversarySelected,
// //               onChanged: (newValue) {
// //                 setState(() {
// //                   isAnniversarySelected = newValue!;
// //                 });
// //               },
// //             ),
// //             CheckboxListTile(
// //               title: Text('Birthday'),
// //               value: isBirthdaySelected,
// //               onChanged: (newValue) {
// //                 setState(() {
// //                   isBirthdaySelected = newValue!;
// //                 });
// //               },
// //             ),
// //             if (isAnniversarySelected || isBirthdaySelected)
// //               DropdownButton<Template>(
// //                 value: selectedTemplate,
// //                 hint: Text('Select a template'),
// //                 onChanged: (template) {
// //                   setState(() {
// //                     selectedTemplate = template;
// //                   });
// //                 },
// //                 items: templates.map<DropdownMenuItem<Template>>((template) {
// //                   return DropdownMenuItem<Template>(
// //                     value: template,
// //                     child: Text(template.name),
// //                   );
// //                 }).toList(),
// //               ),
// //             if (isAnniversarySelected && isBirthdaySelected)
// //               DropdownButton<Template1>(
// //                 value: selectedTemplate1,
// //                 hint: Text('Select a template'),
// //                 onChanged: (template1) {
// //                   setState(() {
// //                     selectedTemplate1 = template1;
// //                   });
// //                 },
// //                 items: templates1.map<DropdownMenuItem<Template1>>((template1) {
// //                   return DropdownMenuItem<Template1>(
// //                     value: template1,
// //                       child: Text(template1.name),
// //                   );
// //                 }).toList(),
// //               ),
// //
// //              if (selectedTemplate != null && selectedTemplate1 != null)
// //               ElevatedButton(
// //                 onPressed: () {
// //                 },
// //                 child: Text('Send'),
// //               ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'dart:io';
//
// void main() {
//   runApp(template());
// }
//
// class template extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Template Example',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: TemplatePage(),
//     );
//   }
// }
//
// class TemplatePage extends StatefulWidget {
//   @override
//   _TemplatePageState createState() => _TemplatePageState();
// }
//
// class _TemplatePageState extends State<TemplatePage> {
//   bool option1Selected = false;
//   bool option2Selected = false;
//   late File selectedFile;
//
//   Future<void> _uploadFile() async {
//     firebase_storage.Reference storageReference = firebase_storage.FirebaseStorage.instance
//         .ref()
//         .child('files/${selectedFile.path.split('/').last}');
//
//     await storageReference.putFile(selectedFile);
//
//     String fileUrl = await storageReference.getDownloadURL();
//
//     await FirebaseFirestore.instance.collection('files').add({
//       'filename': selectedFile.path.split('/').last,
//       'url': fileUrl,
//     });
//
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text('File uploaded to Firebase.'),
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Template Example'),
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             CheckboxListTile(
//               title: Text('Option 1'),
//               value: option1Selected,
//               onChanged: (value) {
//                 setState(() {
//                   option1Selected = value!;
//                 });
//               },
//             ),
//             CheckboxListTile(
//               title: Text('Option 2'),
//               value: option2Selected,
//               onChanged: (value) {
//                 setState(() {
//                   option2Selected = value!;
//                 });
//               },
//             ),
//             if (option1Selected || option2Selected)
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Column(
//                   children: [
//                     ElevatedButton(
//                       onPressed: () async {
//                         XFile? file = await ImagePicker.pickImage(
//                             source: ImageSource.gallery);
//                         setState(() {
//                           selectedFile = file as File;
//                         });
//                       },
//                       child: Text('Select File'),
//                     ),
//                     if (selectedFile != null)
//                       Text('Selected File: ${selectedFile.path}'),
//                   ],
//                 ),
//               ),
//             ElevatedButton(
//               onPressed: () async {
//                 if (selectedFile != null) {
//                   await _uploadFile();
//                 }
//               },
//               child: Text('Submit'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
// import 'package:flutter/material.dart';
// import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
// import 'package:path/path.dart' as path;
// import 'package:image_picker/image_picker.dart';
// import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'dart:io';
//
// void main() {
//   runApp(template());
// }
//
// class template extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Templates',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: TemplatePage(),
//     );
//   }
// }
//
// class TemplatePage extends StatefulWidget {
//   @override
//   _TemplatePageState createState() => _TemplatePageState();
// }
//
// class _TemplatePageState extends State<TemplatePage> {
//   bool option1Selected = false;
//   bool option2Selected = false;
//   File? selectedFile;
//   File? selectedFile1;
//   // Future<void> _uploadFile() async {
//   //   firebase_storage.Reference storageReference = firebase_storage.FirebaseStorage.instance
//   //       .ref()
//   //       .child('files/${selectedFile?.path.split('/').last}')
//   //       .child('files/${selectedFile1?.path.split('/').last}');
//   //
//   //   await storageReference.putFile(selectedFile!);
//   //
//   //   await storageReference.putFile(selectedFile1!);
//   //
//   //   String fileUrl = await storageReference.getDownloadURL();
//   //
//   //   await FirebaseFirestore.instance.collection('files').add({
//   //     'filename': selectedFile?.path.split('/').last,
//   //     'url': fileUrl,
//   //   });
//
//   Future<void> uploadFiles() async {
//     firebase_storage.FirebaseStorage storage =
//         firebase_storage.FirebaseStorage.instance;
//
//     for (var file in selectedFiles) {
//       String fileName = path.basename(file.path ?? '');
//
//       firebase_storage.Reference ref = storage.ref().child(fileName);
//
//       await ref.putFile(File(file.path!));
//     }
//   }
//
//     // await FirebaseFirestore.instance.collection('files').add({
//     //   'filename': selectedFile1?.path.split('/').last,
//     //   'url': fileUrl,
//     // });
//
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text('File uploaded to Firebase.'),
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Template'),
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             CheckboxListTile(
//               title: Text('Birthday'),
//               value: option1Selected,
//               onChanged: (value) {
//                 setState(() {
//                   option1Selected = value!;
//                 });
//               },
//             ),
//             CheckboxListTile(
//               title: Text('Aniversary'),
//               value: option2Selected,
//               onChanged: (value) {
//                 setState(() {
//                   option2Selected = value!;
//                 });
//               },
//             ),
//             if (option1Selected || option2Selected)
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Column(
//                   children: [
//                     ElevatedButton(
//                       onPressed: () async {
//                         XFile? file = await ImagePicker().pickImage(
//                           source: ImageSource.gallery,
//                         );
//                         if (file != null) {
//                           setState(() {
//                             selectedFile = File(file.path);
//                           });
//                         }
//                       },
//                       child: Text('Select File'),
//                     ),
//                     if (selectedFile != null)
//                       Text('Selected File: ${selectedFile?.path}'),
//                   ],
//                 ),
//               ),
//             if(option1Selected && option2Selected)
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Column(
//                   children: [
//                     ElevatedButton(
//                       onPressed: () async {
//                         XFile? file = await ImagePicker().pickImage(
//                           source: ImageSource.gallery,
//                         );
//                         if (file != null) {
//                           setState(() {
//                             selectedFile1 = File(file.path);
//                           });
//                         }
//                       },
//                       child: Text('Select File'),
//                     ),
//                     if (selectedFile1 != null)
//                       Text('Selected File: ${selectedFile1?.path}'),
//                   ],
//                 ),
//               ),
//             ElevatedButton(
//               onPressed: () async {
//                 if (selectedFile1 != null) {
//                   await _uploadFile();
//                   Text('File uploaded succesfully');
//                 }
//               },
//               child: Text('Submit'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:path/path.dart' as path;
import 'package:image_picker/image_picker.dart';
import 'dart:io';

void main() {
  runApp(template());
}

class template extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Templates',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TemplatePage(),
    );
  }
}

class TemplatePage extends StatefulWidget {
  @override
  _TemplatePageState createState() => _TemplatePageState();
}

class _TemplatePageState extends State<TemplatePage> {
  List<File> selectedFiles = [];

  Future<void> uploadFiles() async {
    firebase_storage.FirebaseStorage storage =
        firebase_storage.FirebaseStorage.instance;

    for (var file in selectedFiles) {
      String fileName = path.basename(file.path);

      firebase_storage.Reference ref = storage.ref().child(fileName);

      await ref.putFile(file);
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Files uploaded to Firebase.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Template'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () async {
                List<XFile>? files = await ImagePicker().pickMultiImage(
                 // source: ImageSource.gallery,
                );
                if (files != null && files.isNotEmpty) {
                  setState(() {
                    selectedFiles = files.map((file) => File(file.path)).toList();
                  });
                }
              },
              child: Text('Select Files'),
            ),
            if (selectedFiles.isNotEmpty)
              Column(
                children: [
                  for (var selectedFile in selectedFiles)
                    Text('Selected File: ${selectedFile.path}'),
                ],
              ),
            ElevatedButton(
              onPressed: () async {
                if (selectedFiles.isNotEmpty) {
                  await uploadFiles();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Files uploaded successfully.'),
                    ),
                  );
                }
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
